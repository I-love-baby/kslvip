export KSL="com.pubg.krmobile"
rm -rf /storage/emulated/0/KSL13
mkdir /storage/emulated/0/KSL13
mkdir /storage/emulated/0/KSL13/KR
rm -rf /data/data/$KSL/app_appcache
rm -rf /data/data/$KSL/app_bugly
rm -rf /data/data/$KSL/app_crashrecord
rm -rf /data/data/$KSL/app_databases
rm -rf /data/data/$KSL/app_geolocation
rm -rf /data/data/$KSL/app_tbs
rm -rf /data/data/$KSL/app_textures
rm -rf /data/data/$KSL/app_webview
rm -rf /data/data/$KSL/app_webview_imsdk_inner_webview
rm -rf /data/data/$KSL/cache
rm -rf /data/data/$KSL/code_cache
rm -rf /data/data/$KSL/databases
rm -rf /data/data/$KSL/files
rm -rf /data/data/$KSL/no_backup
cp -R /storage/emulated/legacy/Android/data/com.google.android.gm/files/modpaks/* /storage/emulated/0/Android/data/$KSL/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
am start -n $KSL/com.epicgames.ue4.SplashActivity > /dev/null 2>&1