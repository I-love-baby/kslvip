export KSL="com.tencent.ig"
rm -rf /storage/emulated/0/KSL13
rm -rf /data/data/$KSL/app_appcache
rm -rf /data/data/$KSL/app_bugly
rm -rf /data/data/$KSL/app_crashrecord
rm -rf /data/data/$KSL/app_databases
rm -rf /data/data/$KSL/app_geolocation
rm -rf /data/data/$KSL/app_tbs
rm -rf /data/data/$KSL/app_textures
rm -rf /data/data/$KSL/app_webview
rm -rf /data/data/$KSL/app_webview_imsdk_inner_webview
rm -rf /data/data/$KSL/cache
rm -rf /data/data/$KSL/code_cache
rm -rf /data/data/$KSL/databases
rm -rf /data/data/$KSL/files
rm -rf /data/data/$KSL/no_backup
rm -rf /storage/emulated/0/Android/data/$KSL/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch_0.18.0.12601.pak